BOUGE TA CIRE — REFONTE (prototype)

Ouvrir index.html dans un navigateur pour voir la boutique.
Fichiers : index.html, style.css, script.js.

IMPORTANT AVANT PUBLICATION :
1. Remplacer les 6 produits EXEMPLES de script.js par les 23 vrais produits.
2. Remplacer les photos d'ambiance par les vraies photos de bougies (droits d'utilisation à vérifier).
3. Renseigner les vrais prix et disponibilités si vous voulez les afficher.
4. Tester le lien Instagram, les informations de contact et les modalités de commande.
5. Ajouter mentions légales, politique de confidentialité et CGV selon votre activité.
6. Le panier prépare une demande via Instagram ; aucun paiement en ligne n'est intégré.

Déploiement GitHub Pages : remplacer les fichiers du dépôt par ceux-ci, ou tester sur une branche avant de publier.
