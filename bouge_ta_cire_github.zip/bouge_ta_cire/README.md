# Bouge Ta Cire

Site vitrine de **Bouge Ta Cire**, boutique indépendante de bougies artisanales faites main.

🔗 Site en ligne : https://liloupnt.github.io/bouge_ta_cire/
📸 Instagram : [@bouge_ta_cire](https://www.instagram.com/bouge_ta_cire)

## Collections

| Collection | Bougies |
|---|---|
| ✨ Noël | Monsieur Flocon, Rodolphe, Ange, Casse-Noisette, Le Chalet d’Épices, Pomme de Pin, Grand Sapin, Petit Sapin |
| 🍂 Automne | Le Fantôme, Le Gland, Le Potiron, La Courge, La Citrouille |
| 🕊️ Religieux | Vierge Marie |
| 🍋 Été | Citron d’été, Cocktail fraise, Cocktail Apérol |
| 🐣 Pâques | Lapin dans l’œuf, Petit poussin, Œuf fleuri, Œuf lapin, Œuf triangulaire, Œuf rayé |

## Fonctionnement

Tout le site tient dans **`index.html`** : les photos y sont intégrées directement, il n’a besoin d’aucun autre fichier pour s’afficher. Les images présentes dans le dépôt servent d’archive.

- **Onglets par collection** : générés automatiquement à partir des bougies.
- **Panier** : enregistré dans le navigateur du visiteur ; la commande se finalise par Instagram ou par message.
- **Avis clients** : enregistrés dans le navigateur du visiteur.

## Ajouter une bougie

Dans `index.html`, ajouter un objet dans le tableau `products` :

```js
{
  id: 24,                          // numéro unique
  name: "Nom de la bougie",
  price: 6,                        // en euros (null = « Prix sur demande »)
  category: "noël hiver",          // mots-clés utilisés par la recherche et le filtre
  tag: "Collection Noël",          // collection = onglet
  description: "Description courte.",
  images: ["nom-photo.jpg"]
}
```

L’image doit aussi être déclarée dans `ASSETS` (nom du fichier → image en base64).

Pour changer l’ordre des collections, modifier la liste `COLLECTION_ORDER`.

## Mise en ligne

Le site est publié avec **GitHub Pages** depuis la branche principale : toute modification de `index.html` est en ligne en une à deux minutes.
